package gt.contentchecker;

public enum ContentCheckOutcome {
    PASSED, FAILED, MANUAL_REVIEW_NEEDED
}
