package gt.app.domain;

public enum CommentStatus {
    AWAITING_APPROVAL, SHOWING, HIDDEN, DELETED
}
