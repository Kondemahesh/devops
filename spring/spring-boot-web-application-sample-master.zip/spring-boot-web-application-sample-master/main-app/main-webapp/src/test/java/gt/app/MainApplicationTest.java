package gt.app;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class MainApplicationTest  {

    @Test
    void contextLoads() {
        assertTrue(true, "Context loads !!!");
    }

}


