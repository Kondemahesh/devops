package gt.app.modules.common;

public class BadQueryException extends RuntimeException {
    public BadQueryException(String s) {
        super(s);
    }
}
