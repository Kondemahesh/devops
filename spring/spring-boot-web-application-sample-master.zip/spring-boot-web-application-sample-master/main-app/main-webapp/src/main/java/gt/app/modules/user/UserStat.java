package gt.app.modules.user;

import lombok.Data;

@Data
public class UserStat {

    int numArticle;
    int numComments;
    int userRating;

}
