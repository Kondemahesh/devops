#!/bin/bash

set -e

service tomcat8 start
