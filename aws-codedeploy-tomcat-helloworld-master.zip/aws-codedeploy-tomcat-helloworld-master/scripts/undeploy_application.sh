#!/bin/bash

set -e

rm -fr /usr/share/tomcat8/webapps/*
