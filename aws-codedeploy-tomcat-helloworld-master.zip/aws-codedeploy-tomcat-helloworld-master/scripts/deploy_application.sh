#!/bin/bash

set -e

mv /tmp/VijayJavaHelloWorld.war /usr/share/tomcat8/webapps
